# tests/utils/pipeline_client.py

import asyncio
import httpx
from typing import Any

# The four pipeline steps returned by GET /job/status
PIPELINE_STEPS = ['scraping', 'embedding', 'store_to_db', 'retrieval_generation']


class PipelineClient:

    def __init__(self, base_url: str, timeout: int = 600):
        self.base_url = base_url.rstrip('/')  # e.g. http://127.0.0.1:8080
        self.timeout = timeout

    # ── Step 1: POST /extract ────────────────────────────────────────────

    async def extract(self, urls: list[str], requested_by: str, job_request_name: str) -> str:
        """
        POST /extract
        Body: { requested_by, job_request_name, urls }
        Returns: job_id string
        """
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post(
                f'{self.base_url}/extract',
                json={
                    'requested_by': requested_by,
                    'job_request_name': job_request_name,
                    'urls': urls,
                },
                headers={'accept': 'application/json', 'Content-Type': 'application/json'}
            )
            r.raise_for_status()
            return r.json()['job_id']

    # ── Step 2: poll GET /job/status?job_id= ────────────────────────────

    async def wait_for_completion(self, job_id: str) -> dict:
        """
        Polls GET /job/status?job_id={job_id} with exponential backoff.
        Status values per step: not_started | processing | completed | error
        Returns the final status dict when all steps == 'completed'.
        Raises RuntimeError on any 'error' step.
        Raises TimeoutError if self.timeout is exceeded.
        """
        delay = 5
        elapsed = 0

        async with httpx.AsyncClient(timeout=30) as c:
            while elapsed < self.timeout:
                r = await c.get(
                    f'{self.base_url}/job/status',
                    params={'job_id': job_id},
                    headers={'accept': 'application/json'}
                )
                r.raise_for_status()
                status = r.json()
                # e.g. {'scraping': 'completed', 'embedding': 'processing',
                #        'store_to_db': 'not_started', 'retrieval_generation': 'not_started'}

                if any(status.get(step) == 'error' for step in PIPELINE_STEPS):
                    raise RuntimeError(
                        f'Pipeline error for job_id={job_id}: {status}'
                    )

                if all(status.get(step) == 'completed' for step in PIPELINE_STEPS):
                    return status

                await asyncio.sleep(delay)
                elapsed += delay
                delay = min(delay * 1.5, 30)  # cap at 30s

        raise TimeoutError(
            f'job_id={job_id} did not complete within {self.timeout}s'
        )

    # ── Step 3: GET /view/form?job_id= ──────────────────────────────────

    async def get_form(self, job_id: str) -> dict[str, Any]:
        """
        GET /view/form?job_id={job_id}
        Returns the full AI-extracted form JSON.
        """
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.get(
                f'{self.base_url}/view/form',
                params={'job_id': job_id},
                headers={'accept': 'application/json'}
            )
            r.raise_for_status()
            return r.json()

    # ── Full pipeline run ────────────────────────────────────────────────

    async def run_pipeline(
        self,
        urls: list[str],
        requested_by: str = 'pytest',
        job_request_name: str = 'pytest run',
    ) -> dict[str, Any]:
        job_id = await self.extract(urls, requested_by, job_request_name)
        await self.wait_for_completion(job_id)
        return await self.get_form(job_id)
