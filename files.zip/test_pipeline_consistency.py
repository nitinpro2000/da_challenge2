# tests/test_pipeline_consistency.py

import pytest
import asyncio

from utils.pipeline_client import PipelineClient
from utils.field_config import FIELD_STRATEGIES
from utils.matchers import exact_match, numeric_match, cosine_match, set_match
from utils.report import TestReport, FieldResult


# ── Helper: resolve a field value from nested JSON ───────────────────────

def extract_field_value(data: dict, field_key: str, extractor: str):
    """
    Navigate the JSON using field_key and extractor hint.
    Returns the scalar or structure to be compared.
    """
    parts = field_key.split('.')
    top = data.get(parts[0], {})

    if extractor == 'root':
        return top
    if extractor == 'value':
        return top.get('value')
    if extractor == 'values':  # {values: {key: val}}
        sub = top.get('values', {})
        return sub.get(parts[1]) if len(parts) > 1 else sub
    if extractor == 'annual_cost':
        return top.get('annual_cost')
    if extractor == 'service_parts':
        return top.get('service_parts', {})
    if extractor == 'contact_list':
        contacts = []
        for doc_data in top.values():
            if isinstance(doc_data, dict) and 'values' in doc_data:
                contacts.extend(doc_data['values'])
        subkey = parts[1] if len(parts) > 1 else None
        return [c.get(subkey) for c in contacts] if subkey else contacts
    if extractor == 'kct':
        return top.get('values', {}).get(parts[1])
    if extractor == 'pscm':
        return top

    return top.get('value')  # default


# ── Helper: apply the right matcher ──────────────────────────────────────

def compare_field(rule, ground_val, actual_val) -> tuple[bool, float]:
    if rule.strategy == 'exact':
        return exact_match(ground_val, actual_val)

    if rule.strategy == 'numeric':
        if isinstance(ground_val, dict):  # service_parts dict
            results = [
                numeric_match(ground_val.get(k, 0), actual_val.get(k, 0), rule.threshold)
                for k in set(ground_val) | set(actual_val or {})
            ]
            scores = [r[1] for r in results]
            passed = all(r[0] for r in results)
            return passed, round(sum(scores) / len(scores), 4) if scores else (True, 1.0)
        return numeric_match(ground_val, actual_val, rule.threshold)

    if rule.strategy == 'cosine':
        return cosine_match(str(ground_val or ''), str(actual_val or ''), rule.threshold)

    if rule.strategy == 'set':
        g = ground_val if isinstance(ground_val, list) else [ground_val]
        a = actual_val if isinstance(actual_val, list) else [actual_val]
        return set_match(g, a)

    return False, 0.0


# ── Main test ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_pipeline_output_consistency(
    ground_truth_case: dict,
    pipeline_client: PipelineClient,
):
    """
    For each ground truth fixture:
    1. Re-run the pipeline using the URLs stored in extract_request
    2. Compare every configured field against ground truth
    3. Assert all fields pass their threshold
    """
    case_id = ground_truth_case['test_case_id']
    ground = ground_truth_case['ground_truth']
    extract_req = ground_truth_case['extract_request']

    # ── 1. Run pipeline via POST /extract ─────────────────────────────────
    # Re-use the same requested_by / job_request_name from the fixture
    actual = await pipeline_client.run_pipeline(
        urls=extract_req['urls'],
        requested_by=extract_req.get('requested_by', 'pytest'),
        job_request_name=f"pytest:{case_id}",
    )
    # actual = full JSON response from GET /view/form?job_id=...

    # ── 2. Compare fields ─────────────────────────────────────────────────
    results: list[FieldResult] = []
    failures: list[str] = []

    for field_key, rule in FIELD_STRATEGIES.items():
        ground_val = extract_field_value(ground, field_key, rule.extractor)
        actual_val = extract_field_value(actual, field_key, rule.extractor)

        passed, score = compare_field(rule, ground_val, actual_val)

        results.append(FieldResult(
            field=field_key,
            strategy=rule.strategy,
            threshold=rule.threshold,
            ground_value=ground_val,
            actual_value=actual_val,
            score=score,
            passed=passed,
        ))

        if not passed:
            failures.append(
                f'{field_key}: score={score:.3f} (threshold={rule.threshold}) '
                f'| ground={str(ground_val)[:80]} '
                f'| actual={str(actual_val)[:80]}'
            )

    # ── 3. Write report ───────────────────────────────────────────────────
    report = TestReport(case_id=case_id, field_results=results)
    report.write_json(f'tests/reports/{case_id}.json')
    report.write_html(f'tests/reports/{case_id}.html')

    # ── 4. Assert ─────────────────────────────────────────────────────────
    assert not failures, (
        f'\n[{case_id}] {len(failures)} field(s) failed:\n'
        + '\n'.join(f'  • {f}' for f in failures)
    )
