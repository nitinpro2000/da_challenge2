# tests/utils/matchers.py

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np


def exact_match(ground: str, actual: str) -> tuple[bool, float]:
    g = str(ground).strip().lower()
    a = str(actual).strip().lower()
    passed = g == a
    return passed, 1.0 if passed else 0.0


def numeric_match(ground: float, actual: float, epsilon: float = 0.01) -> tuple[bool, float]:
    try:
        diff = abs(float(ground) - float(actual))
        passed = diff <= epsilon
        # Score: 1.0 if equal, degrades linearly up to 10× epsilon
        score = max(0.0, 1.0 - diff / (epsilon * 10))
        return passed, round(score, 4)
    except (TypeError, ValueError):
        return False, 0.0


def cosine_match(
    ground: str,
    actual: str,
    threshold: float = 0.85
) -> tuple[bool, float]:
    """
    TF-IDF cosine similarity between two strings.
    Returns (passed: bool, score: float 0-1).
    """
    if not ground and not actual:
        return True, 1.0
    if not ground or not actual:
        return False, 0.0

    vectorizer = TfidfVectorizer()
    try:
        tfidf = vectorizer.fit_transform([ground, actual])
        score = float(cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0])
    except ValueError:
        # Handles edge case where both texts are identical single tokens
        score = 1.0 if ground.strip().lower() == actual.strip().lower() else 0.0

    return score >= threshold, round(score, 4)


def set_match(ground: list, actual: list) -> tuple[bool, float]:
    g_set = {str(v).strip().lower() for v in ground}
    a_set = {str(v).strip().lower() for v in actual}

    if g_set == a_set:
        return True, 1.0

    # Jaccard similarity as partial score
    intersection = len(g_set & a_set)
    union = len(g_set | a_set)
    score = intersection / union if union else 0.0
    return False, round(score, 4)
