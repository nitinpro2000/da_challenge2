# tests/test_pipeline_consistency.py

import pytest

from utils.pipeline_client import PipelineClient
from utils.field_config import FIELD_STRATEGIES
from utils.matchers import exact_match, numeric_match, cosine_match, set_match
from utils.report import TestReport, FieldResult


# ── Field extractor ───────────────────────────────────────────────────────

def extract_field_value(data: dict, field_key: str, extractor: str):
    """
    Navigate the JSON using field_key and extractor hint.
    Handles both simple top-level fields and multi-document keyed structures.
    Returns the scalar or structure to be compared.
    """
    parts = field_key.split('.')
    top = data.get(parts[0], {})

    # ── Plain root value (e.g. access_to_customer_information is a bare string)
    if extractor == 'root':
        return top

    # ── Standard .value fields
    if extractor == 'value':
        if isinstance(top, dict):
            return top.get('value')
        return None

    # ── .values sub-dict (contract_details, address_details, etc.)
    if extractor == 'values':
        sub = top.get('values', {}) if isinstance(top, dict) else {}
        return sub.get(parts[1]) if len(parts) > 1 else sub

    # ── initial_agreement_term: may be {} or {"value": N}
    if extractor == 'initial_term':
        if not top or not isinstance(top, dict):
            return None
        return top.get('value')

    # ── key_contract_terms: {values: {term_name: text}}
    if extractor == 'kct':
        return top.get('values', {}).get(parts[1]) if isinstance(top, dict) else None

    # ── contact_details: now keyed by doc filename
    #    { "doc1.pdf": { "values": [{contact_name, contact_email, ...}] }, ... }
    if extractor == 'contact_list_multi_doc':
        subkey = parts[1] if len(parts) > 1 else None
        contacts = []
        if isinstance(top, dict):
            for doc_data in top.values():
                if isinstance(doc_data, dict) and 'values' in doc_data:
                    contacts.extend(doc_data['values'])
        return [c.get(subkey) for c in contacts] if subkey else contacts

    # ── annual_cost: keyed by doc filename
    #    { "doc1.pdf": { "annual_cost": 50000, "service_parts": {...} }, ... }
    #    Strategy: sum all non-null annual_cost values across documents
    if extractor == 'annual_cost_multi_doc':
        if not isinstance(top, dict):
            return None
        total = 0.0
        found_any = False
        for doc_data in top.values():
            if isinstance(doc_data, dict):
                val = doc_data.get('annual_cost')
                if val is not None:
                    total += float(val)
                    found_any = True
        return total if found_any else None

    # ── service_parts: merge all non-null service_parts dicts across documents
    if extractor == 'service_parts_multi_doc':
        if not isinstance(top, dict):
            return {}
        merged: dict = {}
        for doc_data in top.values():
            if isinstance(doc_data, dict):
                parts_val = doc_data.get('service_parts')
                if isinstance(parts_val, dict):
                    for k, v in parts_val.items():
                        merged[k] = merged.get(k, 0.0) + float(v or 0)
        return merged if merged else None

    # ── notice_days: keyed by doc filename → {value: N}
    #    Take the first non-null value found across documents
    if extractor == 'notice_days_multi_doc':
        if not isinstance(top, dict):
            return None
        for doc_data in top.values():
            if isinstance(doc_data, dict):
                val = doc_data.get('value')
                if val is not None:
                    return val
        return None

    # ── vendor_access_to_pscm_information: {value: [{has_access, access_type, ...}]}
    #    Flatten to a set of (has_access, access_type_key) strings for set comparison
    if extractor == 'pscm_value_list':
        if not isinstance(top, dict):
            return []
        items = top.get('value', [])
        if not isinstance(items, list):
            return []
        # Represent each entry as a canonical string for set matching
        result = []
        for item in items:
            if isinstance(item, dict):
                has_access = item.get('has_access', '')
                access_type = item.get('access_type', {}) or {}
                # Collect which access_type flags are 'Y'
                active_types = sorted(k for k, v in access_type.items() if v == 'Y')
                result.append(f"{has_access}|{','.join(active_types)}")
        return result

    # ── internal_owners: {values: [...]}
    if extractor == 'values' and parts[0] == 'internal_owners':
        return top.get('values', []) if isinstance(top, dict) else []

    # Default: .value
    if isinstance(top, dict):
        return top.get('value')
    return None


# ── Matcher dispatcher ────────────────────────────────────────────────────

def compare_field(rule, ground_val, actual_val) -> tuple[bool, float]:
    if rule.strategy == 'exact':
        return exact_match(ground_val, actual_val)

    if rule.strategy == 'numeric':
        if isinstance(ground_val, dict):  # service_parts merged dict
            all_keys = set(ground_val or {}) | set(actual_val or {})
            if not all_keys:
                return True, 1.0
            results = [
                numeric_match(
                    (ground_val or {}).get(k, 0),
                    (actual_val or {}).get(k, 0),
                    rule.threshold
                )
                for k in all_keys
            ]
            scores = [r[1] for r in results]
            passed = all(r[0] for r in results)
            return passed, round(sum(scores) / len(scores), 4)
        # Either value being None → treat as missing → fail with score 0
        if ground_val is None and actual_val is None:
            return True, 1.0
        if ground_val is None or actual_val is None:
            return False, 0.0
        return numeric_match(ground_val, actual_val, rule.threshold)

    if rule.strategy == 'cosine':
        return cosine_match(str(ground_val or ''), str(actual_val or ''), rule.threshold)

    if rule.strategy == 'set':
        g = ground_val if isinstance(ground_val, list) else ([ground_val] if ground_val else [])
        a = actual_val if isinstance(actual_val, list) else ([actual_val] if actual_val else [])
        return set_match(g, a)

    return False, 0.0


# ── Main test ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_pipeline_output_consistency(
    ground_truth_case: dict,
    pipeline_client: PipelineClient,
):
    """
    For each ground truth fixture:
    1. Re-run the pipeline using the URLs stored in extract_request
    2. Compare every configured field against ground truth
    3. Assert all fields pass their threshold
    """
    case_id = ground_truth_case['test_case_id']
    ground = ground_truth_case['ground_truth']
    extract_req = ground_truth_case['extract_request']

    # ── 1. Re-run pipeline ────────────────────────────────────────────────
    actual = await pipeline_client.run_pipeline(
        urls=extract_req['urls'],
        requested_by=extract_req.get('requested_by', 'pytest'),
        job_request_name=f"pytest:{case_id}",
    )

    # ── 2. Compare fields ─────────────────────────────────────────────────
    results: list[FieldResult] = []
    failures: list[str] = []

    for field_key, rule in FIELD_STRATEGIES.items():
        ground_val = extract_field_value(ground, field_key, rule.extractor)
        actual_val = extract_field_value(actual, field_key, rule.extractor)

        passed, score = compare_field(rule, ground_val, actual_val)

        results.append(FieldResult(
            field=field_key,
            strategy=rule.strategy,
            threshold=rule.threshold,
            ground_value=ground_val,
            actual_value=actual_val,
            score=score,
            passed=passed,
        ))

        if not passed:
            failures.append(
                f'{field_key}: score={score:.3f} (threshold={rule.threshold}) '
                f'| ground={str(ground_val)[:80]} '
                f'| actual={str(actual_val)[:80]}'
            )

    # ── 3. Write report ───────────────────────────────────────────────────
    report = TestReport(case_id=case_id, field_results=results)
    report.write_json(f'tests/reports/{case_id}.json')
    report.write_html(f'tests/reports/{case_id}.html')

    # ── 4. Assert ─────────────────────────────────────────────────────────
    assert not failures, (
        f'\n[{case_id}] {len(failures)} field(s) failed:\n'
        + '\n'.join(f'  • {f}' for f in failures)
    )
