# tests/utils/field_config.py

from dataclasses import dataclass
from typing import Literal

Strategy = Literal['exact', 'numeric', 'cosine', 'set']


@dataclass
class FieldRule:
    strategy: Strategy
    threshold: float = 1.0  # exact/set: 1.0 | numeric: epsilon | cosine: min score
    extractor: str = 'value'  # determines how to pull the value from the JSON blob


FIELD_STRATEGIES: dict[str, FieldRule] = {
    # ── Exact match ──────────────────────────────────────────────────────
    'vendor_name': FieldRule('exact'),                                          # .value
    'ein': FieldRule('exact'),                                                  # .value
    'risk': FieldRule('exact'),                                                 # .value
    'access_to_customer_information': FieldRule('exact', extractor='root'),     # plain string
    'is_service_available': FieldRule('exact'),                                 # .value
    'is_vendor_service_available': FieldRule('exact'),                          # .value
    'investment_decision_useful': FieldRule('exact'),                           # .value
    'contract_details.contract_type': FieldRule('exact', extractor='values'),
    'contract_details.contract_start_date': FieldRule('exact', extractor='values'),
    'contract_details.contract_end_date': FieldRule('exact', extractor='values'),
    'initial_agreement_term': FieldRule('exact', extractor='initial_term'),     # may be {}
    'address_details.city': FieldRule('exact', extractor='values'),
    'address_details.state': FieldRule('exact', extractor='values'),
    'address_details.country': FieldRule('exact', extractor='values'),
    'address_details.postal_code': FieldRule('exact', extractor='values'),
    'contact_details.contact_email': FieldRule('exact', extractor='contact_list_multi_doc'),
    'contact_details.contact_name': FieldRule('exact', extractor='contact_list_multi_doc'),
    'contact_details.contact_relationship': FieldRule('exact', extractor='contact_list_multi_doc'),

    # ── Numeric tolerance (epsilon) ───────────────────────────────────────
    # annual_cost is now keyed by document filename — aggregate across all docs
    'annual_cost.annual_cost': FieldRule('numeric', threshold=0.01, extractor='annual_cost_multi_doc'),
    'annual_cost.service_parts': FieldRule('numeric', threshold=0.01, extractor='service_parts_multi_doc'),
    'contract_details.contract_value': FieldRule('numeric', threshold=0.01, extractor='values'),
    # notice_days is keyed by document filename — take first non-null value
    'notice_days': FieldRule('numeric', threshold=0.01, extractor='notice_days_multi_doc'),

    # ── Cosine similarity (threshold = min acceptable score) ─────────────
    'service_name': FieldRule('cosine', threshold=0.90),
    'service_description': FieldRule('cosine', threshold=0.85),
    'service_benefit_for': FieldRule('cosine', threshold=0.85),
    'address_details.website': FieldRule('cosine', threshold=0.95, extractor='values'),
    'key_contract_terms.Fees & Payment': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Confidentiality': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Indemnification': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Scope / Services': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Dispute Resolution': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Intellectual Property': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Acceptable Use / Restrictions': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Term, Termination & Suspension': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Customer Content / Ownership & Usage': FieldRule('cosine', threshold=0.80, extractor='kct'),
    'key_contract_terms.Warranties & Limitation of Liability': FieldRule('cosine', threshold=0.80, extractor='kct'),

    # ── Set match ─────────────────────────────────────────────────────────
    'internal_owners': FieldRule('set', extractor='values'),
    # vendor_access_to_pscm_information is now a list under .value
    'vendor_access_to_pscm_information': FieldRule('set', extractor='pscm_value_list'),
}
