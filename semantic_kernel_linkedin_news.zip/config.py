import os

SERPAPI_API_KEY = os.getenv("SERPAPI_API_KEY", "your-serpapi-api-key")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "your-gemini-api-key")
