# tests/utils/report.py

import json
import pathlib
from dataclasses import dataclass, asdict
from datetime import datetime, timezone


@dataclass
class FieldResult:
    field: str
    strategy: str
    threshold: float
    ground_value: object
    actual_value: object
    score: float
    passed: bool


@dataclass
class TestReport:
    case_id: str
    field_results: list[FieldResult]

    @property
    def pass_rate(self) -> float:
        if not self.field_results:
            return 0.0
        return sum(r.passed for r in self.field_results) / len(self.field_results)

    def write_json(self, path: str):
        pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
        payload = {
            'case_id': self.case_id,
            'run_at': datetime.now(timezone.utc).isoformat(),
            'pass_rate': round(self.pass_rate, 4),
            'total': len(self.field_results),
            'passed': sum(r.passed for r in self.field_results),
            'failed': sum(not r.passed for r in self.field_results),
            'fields': [asdict(r) for r in self.field_results],
        }
        pathlib.Path(path).write_text(json.dumps(payload, indent=2, default=str), encoding='utf-8')

    def write_html(self, path: str):
        rows = ''
        for r in self.field_results:
            colour = '#d4edda' if r.passed else '#f8d7da'
            rows += (
                f'<tr style="background:{colour}">'
                f'<td>{r.field}</td><td>{r.strategy}</td>'
                f'<td>{r.threshold}</td><td>{r.score:.4f}</td>'
                f'<td>{"PASS" if r.passed else "FAIL"}</td>'
                f'<td style="font-size:11px">{str(r.ground_value)[:120]}</td>'
                f'<td style="font-size:11px">{str(r.actual_value)[:120]}</td>'
                f'</tr>'
            )

        html = f'''<!DOCTYPE html><html><head><title>{self.case_id}</title>
<style>table{{border-collapse:collapse;width:100%}}
th,td{{border:1px solid #ccc;padding:6px 10px;text-align:left}}
th{{background:#1F4E79;color:#fff}}</style></head>
<body><h2>{self.case_id}</h2>
<p>Pass rate: <b>{self.pass_rate * 100:.1f}%</b></p>
<table><tr><th>Field</th><th>Strategy</th><th>Threshold</th>
<th>Score</th><th>Result</th><th>Ground Truth</th><th>Actual</th></tr>
{rows}</table></body></html>'''

        pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
        pathlib.Path(path).write_text(html, encoding='utf-8')
