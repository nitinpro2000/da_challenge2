"""scripts/create_ground_truth.py

Run once per vendor to create the ground truth fixture.

Usage:
    python scripts/create_ground_truth.py \\
        --case-id hitachi_sow \\
        --description "Hitachi SOW Ad Hoc TM Rate" \\
        --requested-by "Test" \\
        --job-request-name "Hitachi SOW Test Case" \\
        --url "https://pscmdevtredenceaze.blob.core.windows.net/vendormanagement/PSCM - Hitachi SOW.pdf"
"""

import httpx
import json
import time
import argparse
import pathlib
from datetime import datetime, timezone

BASE_URL = 'http://127.0.0.1:8080'
OUT_DIR = pathlib.Path('tests/fixtures/ground_truth')
OUT_DIR.mkdir(parents=True, exist_ok=True)

PIPELINE_STEPS = ['scraping', 'embedding', 'store_to_db', 'retrieval_generation']


def poll_until_complete(job_id: str, timeout: int = 600) -> None:
    """Poll GET /job/status?job_id= until all steps are 'completed'."""
    delay = 5
    elapsed = 0

    while elapsed < timeout:
        r = httpx.get(
            f'{BASE_URL}/job/status',
            params={'job_id': job_id},
            headers={'accept': 'application/json'}
        )
        r.raise_for_status()
        status = r.json()  # e.g. {'scraping': 'completed', 'embedding': 'processing', ...}

        print(f'  Status: {status}')

        if any(status.get(step) == 'error' for step in PIPELINE_STEPS):
            raise RuntimeError(f'Pipeline error: {status}')

        if all(status.get(step) == 'completed' for step in PIPELINE_STEPS):
            print('  ✓ All steps completed')
            return

        time.sleep(delay)
        elapsed += delay
        delay = min(delay * 1.5, 30)  # exponential backoff, cap at 30s

    raise TimeoutError(f'Pipeline did not complete within {timeout}s')


def create_ground_truth(
    case_id: str,
    description: str,
    requested_by: str,
    job_request_name: str,
    urls: list[str],
) -> None:
    print(f'Creating ground truth for: {case_id}')

    # 1. POST /extract
    extract_payload = {
        'requested_by': requested_by,
        'job_request_name': job_request_name,
        'urls': urls,
    }

    r = httpx.post(
        f'{BASE_URL}/extract',
        json=extract_payload,
        headers={'accept': 'application/json', 'Content-Type': 'application/json'},
        timeout=30
    )
    r.raise_for_status()
    job_id = r.json()['job_id']
    print(f'  job_id: {job_id}')

    # 2. Poll GET /job/status?job_id=
    poll_until_complete(job_id)

    # 3. GET /view/form?job_id=
    r = httpx.get(
        f'{BASE_URL}/view/form',
        params={'job_id': job_id},
        headers={'accept': 'application/json'},
        timeout=30
    )
    r.raise_for_status()
    form_value = r.json()

    # 4. Write fixture file
    fixture = {
        'test_case_id': case_id,
        'description': description,
        'created_at': datetime.now(timezone.utc).isoformat(),
        'created_by': requested_by,
        'pipeline_version': 'gemini-2.5-flash',
        'extract_request': extract_payload,
        'ground_truth': form_value,
    }

    out_path = OUT_DIR / f'{case_id}.json'
    out_path.write_text(json.dumps(fixture, indent=2), encoding='utf-8')
    print(f'  ✓ Saved → {out_path}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--case-id', required=True)
    parser.add_argument('--description', default='')
    parser.add_argument('--requested-by', default='Test')
    parser.add_argument('--job-request-name', default='Test Request')
    parser.add_argument('--url', action='append', dest='urls', required=True)

    args = parser.parse_args()

    create_ground_truth(
        case_id=args.case_id,
        description=args.description,
        requested_by=args.requested_by,
        job_request_name=args.job_request_name,
        urls=args.urls,
    )
