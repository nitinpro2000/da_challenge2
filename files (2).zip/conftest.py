# tests/conftest.py

import json
import os
import pathlib
import sys
import pytest

# Ensure the tests/ directory is on sys.path so 'utils' is importable
# regardless of where pytest is invoked from.
sys.path.insert(0, str(pathlib.Path(__file__).parent))

from utils.pipeline_client import PipelineClient

GROUND_TRUTH_DIR = pathlib.Path(__file__).parent / 'fixtures' / 'ground_truth'


def load_all_ground_truth() -> list[dict]:
    """Discover and parse every ground truth JSON file."""
    return [
        json.loads(p.read_text(encoding='utf-8'))
        for p in sorted(GROUND_TRUTH_DIR.glob('*.json'))
    ]


@pytest.fixture(scope='session')
def pipeline_client() -> PipelineClient:
    """
    Session-scoped client --- one instance reused for all tests.
    Reads PIPELINE_BASE_URL from environment (default: http://127.0.0.1:8080).
    """
    return PipelineClient(
        base_url=os.environ.get('PIPELINE_BASE_URL', 'http://127.0.0.1:8080'),
        timeout=int(os.environ.get('PIPELINE_TIMEOUT', '600')),
    )


def pytest_generate_tests(metafunc):
    """
    Auto-parametrise any test requesting 'ground_truth_case'
    with every JSON file found in tests/fixtures/ground_truth/.
    """
    if 'ground_truth_case' in metafunc.fixturenames:
        cases = load_all_ground_truth()
        metafunc.parametrize(
            'ground_truth_case',
            cases,
            ids=[c['test_case_id'] for c in cases]
        )
